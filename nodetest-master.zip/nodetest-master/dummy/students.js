const students = [
  {
    id: 1,
    name: 'Sean Grey',
    age: 24,
  },
  {
    id: 2,
    name: 'John Doe',
    age: 26,
  },
  {
    id: 3,
    name: 'Janet Dane',
    age: 19,
  },
];

export default students;